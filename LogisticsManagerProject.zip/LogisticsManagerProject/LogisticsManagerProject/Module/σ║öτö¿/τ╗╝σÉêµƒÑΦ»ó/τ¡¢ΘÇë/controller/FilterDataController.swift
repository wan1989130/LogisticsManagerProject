//
//  FilterDataController.swift
//  LogisticsManagerProject
//
//  Created by 王岩 on 2018/11/11.
//  Copyright © 2018年 王岩. All rights reserved.
//

import UIKit
import ObjectMapper
class FilterDataController: BaseDataController {
    @IBOutlet weak var startTimeLabel: UILabel!
    
}
