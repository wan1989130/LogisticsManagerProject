//
//  PersonMessageMode.swift
//  Logistics
//
//  Created by 王岩 on 2018/5/24.
//  Copyright © 2018年 王岩. All rights reserved.
//

import UIKit

class PersonMessageMode: BaseModel {
    var realName = ""
    var phone = ""
    var idCard = ""//身份证
    var address = ""//长住地主
    var addressDetail = ""//详细地址
    var frontUrl = ""//正面url
    var backUrl = ""//背面面url

}
